
from flask import Blueprint, render_template, abort
import markdown
import os

blog_bp = Blueprint('blog', __name__, url_prefix='/blog')

def load_markdown(filename):
    path = os.path.join('blog', 'posts', f'{filename}.md')
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return markdown.markdown(f.read())
    return None

@blog_bp.route('/')
def blog_home():
    posts = [f.replace('.md', '') for f in os.listdir('blog/posts') if f.endswith('.md')]
    return render_template('blog_home.html', posts=posts)

@blog_bp.route('/<slug>')
def blog_post(slug):
    html_content = load_markdown(slug)
    if html_content:
        return render_template('blog_post.html', content=html_content, slug=slug)
    else:
        abort(404)
